package lec22Pjt001;

public class MainClass {

	public static void main(String[] args) {
		
		AbstractClassEx ex = new ClassEx(10, "java");
		ex.fun1();
		ex.fun2();
	}
}
