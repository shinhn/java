package lec21Pjt001;

public interface InterfaceA {

	public void funA();
	
}
