package lec21Pjt001;

public interface InterfaceC {

	public void funC();
	
}
