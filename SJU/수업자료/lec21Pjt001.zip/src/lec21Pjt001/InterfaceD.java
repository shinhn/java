package lec21Pjt001;

public interface InterfaceD {

	public void funD();
	
}
