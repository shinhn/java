package lec21Pjt001;

public interface InterfaceB {

	public void funB();
	
}
