package lec19Pjt001;

public class FirstChildClass extends ParentClass {

	public FirstChildClass() {
		
		System.out.println("FirstChildClass constructor");
		
	}

	@Override
	public void makeJJajang() {
		
		System.out.println(" -- FirstChildClass's makeJJajang() START --");
		
	}
	
}
