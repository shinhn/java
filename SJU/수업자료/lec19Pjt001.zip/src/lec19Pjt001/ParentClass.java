package lec19Pjt001;

public class ParentClass {

	int openYear = 1995;
	
	public ParentClass() {
		
		System.out.println("ParentClass constructor");
		
	}
	
	public void makeJJajang() {
		
		System.out.println(" -- makeJJajang() START --");
		
	}
	
}
