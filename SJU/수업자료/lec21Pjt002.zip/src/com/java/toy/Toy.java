package com.java.toy;

public interface Toy {

	public void walk();
	public void run();
	public void alarm();
	public void light();
	
}
