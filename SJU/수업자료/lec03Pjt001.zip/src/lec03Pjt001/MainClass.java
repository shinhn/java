package lec03Pjt001;

public class MainClass {

	public static void main(String[] args) {
		
		int i;	// ���� ����
		i = 10;	// ���� �ʱ�ȭ
		System.out.println("i = " + i);
		
		int j = 20;	// ���� ����&�ʱ�ȭ
		System.out.println("j = " + j);
		
		System.out.println("=================================");
		
		int num = 0;
		System.out.println("num = " + num);
		
		num = 10;
		System.out.println("num = " + num);
		
		num = 100;
		System.out.println("num = " + num);
		
		num = 0;
		System.out.println("num = " + num);

	}

}
