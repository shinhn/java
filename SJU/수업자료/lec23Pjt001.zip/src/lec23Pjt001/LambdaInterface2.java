package lec23Pjt001;

public interface LambdaInterface2 {
	
	public void method(String s1);
	
}
