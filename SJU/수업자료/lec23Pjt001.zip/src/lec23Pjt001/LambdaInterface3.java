package lec23Pjt001;

public interface LambdaInterface3 {
	
	public void method();
	
}
