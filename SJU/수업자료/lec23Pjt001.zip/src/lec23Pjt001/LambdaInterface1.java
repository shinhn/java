package lec23Pjt001;

public interface LambdaInterface1 {
	
	public void method(String s1, String s2, String s3);
	
}
