package lec23Pjt001;

public interface LambdaInterface4 {
	
	public int method(int x, int y);
	
}
