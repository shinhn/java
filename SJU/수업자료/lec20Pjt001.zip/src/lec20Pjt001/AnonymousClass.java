package lec20Pjt001;

public class AnonymousClass {

	public AnonymousClass() {
		System.out.println("AnonymousClass constructor");
	}
	
	public void method() {
		
		System.out.println(" -- AnonymousClass's method START -- ");
		
	}
	
}
