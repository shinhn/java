package lec18Pjt001;

public class ChildClass extends ParentClass {

	public ChildClass() {
		
		System.out.println("ChildClass constructor");
		
	}
	
	public void childFun() {
		
		System.out.println("-- childFun() START -- ");
		
	}
}
