package com.java.dailyJournal;

public class DailyJournal {

}
