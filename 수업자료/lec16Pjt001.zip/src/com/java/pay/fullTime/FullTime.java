package com.java.pay.fullTime;

public class FullTime {

}
