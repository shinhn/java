package com.java.pay.partTime;

public class PartTime {

}
