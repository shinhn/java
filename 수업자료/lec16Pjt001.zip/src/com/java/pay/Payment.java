package com.java.pay;

public class Payment {

}
