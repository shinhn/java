package com.java.util;

public class Util {

}
