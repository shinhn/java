package com.java.welfare;

public class Welfare {

}
