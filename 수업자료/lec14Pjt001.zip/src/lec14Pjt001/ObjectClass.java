package lec14Pjt001;

public class ObjectClass {

	
	public ObjectClass() {
		
		System.out.println("ObjectClass constructor");
		
	}
	
	public void getInfo() {
		
		System.out.println(" -- getInfo method -- ");
		
	}
	
}
